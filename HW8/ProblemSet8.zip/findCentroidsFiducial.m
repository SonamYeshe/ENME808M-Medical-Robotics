%% This script should find the centre locations of the fiducials
% Using pointers from Lecture slides and an idea on a example workflow 
% in findCentroidsTargets.m isolate the fiducial circles and find the
% centre position of these fiducial markers