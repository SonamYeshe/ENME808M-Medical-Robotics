%% This script will segment the three circle of the target rings
% The pipeline here is just for reference. You can be creative and are free
% (encouraged) to try your own approach
%% Read the Image convert to grayscale 
%img = imread('img.png');

%% Crop the image to get just the slice
%im_slice = imcrop(img_g);

%% Apply Noise Removal and contrast enhancement (if you like to)
%img_clean = medfilt2(im_slice,[3 3]);
%img_g_contrast = imadjust(img_clean);

%% You May sharpen the image for more sharp edges
%img_g = imsharpen(img_g_contrast);

%% Choose an appropriate threshold to segment the body of the target
%bw_1 = img_g < threshold;

%% Remove any unwanted blobs by querying the area or some morphological cleaning
% see 'bwareaopen'

%% Invert the Image to get blobs corresponding to the internal circles of the target
%bw_2 = 1 - bw_1;

%% Query the region properties using properties that can isolate circular blobs
%label = bwlabel(bw_3);
%stats = regionprops(logical(bw_3), 'Area', 'Centroid', 'Eccentricity');

% Iterate over stats and pick only those blobs that fits the circularity 
% criteria
%% You may Process the image further using dilation to complete circularity
%structelem = strel('disk',1);
%bw_4 = imdilate(bw_3, structelem);


%% Get the centroids of the isolated circular blobs
%label2 = bwlabel(bw_4);
%stats2 = regionprops(logical(bw_5),'Centroid');

% Iterate over the centroids to gather the centroid positions. 

%% Plot the contour and centroid position on top of the image
% Check bwboundaries/bwperim
